import Foundation
var str = "Hola mundo"
var cadena = "Hola mundo2"
print(str)